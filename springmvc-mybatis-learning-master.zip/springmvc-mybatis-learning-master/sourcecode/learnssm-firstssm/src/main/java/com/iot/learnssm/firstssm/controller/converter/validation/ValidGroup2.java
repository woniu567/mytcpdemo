package com.iot.learnssm.firstssm.controller.converter.validation;

/**
 * Created by brian on 2016/3/6.
 */
public interface ValidGroup2 {
    //接口中不需要定义任何方法，仅是对不同的校验规则进行分组

}
