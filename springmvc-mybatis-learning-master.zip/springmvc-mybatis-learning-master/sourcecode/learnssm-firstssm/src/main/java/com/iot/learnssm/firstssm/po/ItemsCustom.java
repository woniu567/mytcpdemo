package com.iot.learnssm.firstssm.po;

/**
 * Created by Brian on 2016/3/2.
 * 商品信息的扩展类
 */
public class ItemsCustom extends Items {
    //添加商品信息的扩展属性
}
