package com.iot.mybatis.po;

/**
 * Created by Brian on 2016/2/24.
 */
public class UserCustom extends User {
}
